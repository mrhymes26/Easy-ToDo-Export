# Todo Export - .NET 8 Kompatible Version

Diese Version des Todo Export Projekts ist optimiert, um mit **allen .NET 8 Runtime-Versionen** zu funktionieren.

## Unterschiede zur Original-Version

### Hauptänderungen in der `.csproj`-Datei:

1. **`<SelfContained>false</SelfContained>`**
   - Die App wird als "framework-dependent" gebaut
   - Verwendet die installierte .NET Runtime statt eine eigene mitzubringen
   - Funktioniert mit jeder installierten .NET 8.x Runtime

2. **`<RollForward>Major</RollForward>`**
   - Ermöglicht automatisches Roll-Forward zu neueren .NET 8 Versionen
   - Die App kann mit .NET 8.0.0, 8.0.18, 8.0.x oder höheren 8.x Versionen laufen

## Kompatibilität

Diese Version funktioniert mit:
- ✅ .NET Runtime 8.0.0
- ✅ .NET Runtime 8.0.18
- ✅ .NET Runtime 8.0.x (alle Patch-Versionen)
- ✅ .NET Runtime 8.x (zukünftige Minor-Versionen)

## Voraussetzungen

Auf dem Zielsystem muss installiert sein:
- **Microsoft.NETCore.App** Runtime 8.0.x oder höher
- **Microsoft.WindowsDesktop.App** Runtime 8.0.x oder höher

Prüfen Sie die installierten Runtimes mit:
```bash
dotnet --list-runtimes
```

## Build und Ausführung

```bash
dotnet clean
dotnet build
dotnet run
```

Oder für Release:
```bash
dotnet build -c Release
```

Die kompilierte Anwendung befindet sich in:
- Debug: `bin/Debug/net8.0-windows/TodoExport.exe`
- Release: `bin/Release/net8.0-windows/TodoExport.exe`

## Warum diese Version?

Die Original-Version kann bei der Ausführung eine Fehlermeldung zeigen, dass .NET 8 benötigt wird, obwohl eine .NET 8 Runtime installiert ist. Dies liegt daran, dass die `runtimeconfig.json` eine spezifische Version (z.B. 8.0.0) erwartet, während auf dem System eine neuere Version (z.B. 8.0.18) installiert ist.

Diese Version löst das Problem durch:
- Framework-dependent Deployment (keine feste Runtime-Version)
- RollForward-Policy für automatische Kompatibilität
- Flexiblere Runtime-Erkennung

## Weitere Informationen

Alle anderen Funktionen und Features sind identisch mit der Original-Version.

